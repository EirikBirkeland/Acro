#!/bin/bash

echo "Your choice ?"
echo "1) Perl"
echo "2) Sed"
echo "3) quit"
read case;

# Delete tiny files (TODO: Add check for whether header row contains NO EN DA SV)

shopt -s nullglob
filearray=( *.csv )
for item in "${filearray[@]}"
do
    bytes=$(cat "$item" | wc -m)
    if [ "$bytes" -lt 100 ]; then
        rm "$item"
        echo "$item is only $bytes bytes and has been deleted"
    fi
done

# Check encoding and quarantine non-UTF-8.
shopt -s nullglob
filearray=( *.csv )
for item in "${filearray[@]}"
    do
    encoding=$(uchardet "$item")
    if ! [ "$encoding" = "UTF-8" ]; then
        mv $item $item.bad
    fi
done

case $case in

 1)
# Replaces " in safe positions - i.e. next to tabs and ^ and $. 0.380 sec

   perl -pi.bak -e '
    s/^\xEF\xBB\xBF//; # Removes BOM (Byte order mark) to allow for ^ matching with Perl.
    s/(?<=[,"\t]),(?=[,"\t])/\t/g;
    s/^,/\t/g;
    s/,$/\t/g;
    s/"\t/\t/g;
    s/\t"/\t/g;
    s/^"//g;
    s/"$//g' *.csv
    ;;

 2)
    printf "\future option\n"
    ;;
 3)
    break
    ;;
 *) printf "\ninvalid option\n";;

esac
