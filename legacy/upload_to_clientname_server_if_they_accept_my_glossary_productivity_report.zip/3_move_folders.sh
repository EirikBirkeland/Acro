#!/bin/bash

mkdir norsk
mv *NORSK* norsk
mkdir dansk
mv *DANSK* dansk
mkdir svenska
mv *SVENSKA* svenska
mkdir suomi
mv *SUOMI* suomi
mkdir nordic_all
mv *NORDIC_ALL* nordic_all
